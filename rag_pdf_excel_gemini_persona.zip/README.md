# PDF + Excel Q&A (Gemini, Personas, OCR) — Local RAG

This app lets you upload **multiple PDFs and Excels**, then ask questions. It uses **Gemini (free API via Google AI Studio)** with a **persona selector** (Plant Operator, Corporate Employee, General Employee) and a stronger **retrieval pipeline** (BM25 + dense + cross‑encoder rerank). It also supports **OCR** for scanned PDFs and an **Excel SQL** mode using DuckDB.

## Requirements
- Python 3.10+
- A **Gemini API key** from Google AI Studio (free tier): https://aistudio.google.com/
- (Optional) **Tesseract OCR** installed and on PATH for scanned PDFs:
  - macOS: `brew install tesseract`
  - Ubuntu: `sudo apt-get install tesseract-ocr`
  - Windows: installer from tesseract-ocr.github.io

## Setup
```bash
pip install -r requirements.txt
# set your key
export GEMINI_API_KEY=YOUR_KEY   # PowerShell: $env:GEMINI_API_KEY="YOUR_KEY"
```

## Run
```bash
streamlit run app/streamlit_app.py
```

## Features
- **Personas** (choose in UI):
  - Plant Operator → safety-first, SOP/checklist style, actionable steps
  - Corporate Employee → KPIs/ROI/risks, concise executive tone
  - General Employee → plain-language guidance
- **RAG**: BM25 + dense vectors (FAISS) + **cross‑encoder** rerank for better context
- **Excel SQL**: Gemini auto-generates **DuckDB SQL** for exact numbers and aggregations
- **OCR**: toggle on for image-only PDFs
- All data stays **local** except the prompts sent to **Gemini** (your choice to use the online API).