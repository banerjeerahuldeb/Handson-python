import os, io, pathlib, shutil, pickle
import streamlit as st
from typing import List, Dict, Any
from pypdf import PdfReader
from app.utils import excel_to_duckdb, excel_to_text
from app.ocr import ocr_pdf
from app.retriever import build_dense_index, hybrid_search
from app.gemini_client import gemini_chat_text, gemini_text_only
import duckdb

INDEX_DIR = "indexes"
UPLOAD_DIR = "uploads"

st.set_page_config(page_title="PDF + Excel Q&A — Gemini + Personas", layout="wide")

st.sidebar.title("📁 Upload & Index")
uploaded_files = st.sidebar.file_uploader(
    "Upload PDFs and/or Excel files (.pdf, .xlsx, .xls)",
    type=["pdf","xlsx","xls"],
    accept_multiple_files=True
)

use_ocr = st.sidebar.checkbox("Use OCR for scanned PDFs (slower)", value=False)

if st.sidebar.button("Clear uploads"):
    shutil.rmtree(UPLOAD_DIR, ignore_errors=True)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    st.sidebar.success("Uploads cleared.")

if st.sidebar.button("(Re)build Index"):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.makedirs(INDEX_DIR, exist_ok=True)
    saved_paths = []
    if uploaded_files:
        for uf in uploaded_files:
            out_path = os.path.join(UPLOAD_DIR, uf.name)
            with open(out_path, "wb") as f:
                f.write(uf.read())
            saved_paths.append(out_path)
    else:
        saved_paths = [os.path.join(UPLOAD_DIR, p) for p in os.listdir(UPLOAD_DIR)]

    chunks, sources = [], []

    for path in saved_paths:
        p = pathlib.Path(path)
        try:
            if p.suffix.lower() == ".pdf":
                reader = PdfReader(path)
                full_text = []
                for page in reader.pages:
                    txt = page.extract_text() or ""
                    full_text.append(txt)
                text = "\n".join(full_text)
                if use_ocr and (not text.strip()):
                    text = ocr_pdf(path)
                words = text.split()
                size, overlap = 180, 30
                i = 0
                while i < len(words):
                    ck = " ".join(words[i:i+size])
                    if ck.strip():
                        chunks.append(ck); sources.append(f"{p.name} (PDF)")
                    i += size - overlap
            elif p.suffix.lower() in (".xlsx",".xls"):
                text = excel_to_text(path)
                words = text.split()
                size, overlap = 220, 40
                i = 0
                while i < len(words):
                    ck = " ".join(words[i:i+size])
                    if ck.strip():
                        chunks.append(ck); sources.append(f"{p.name} (Excel)")
                    i += size - overlap
        except Exception as e:
            st.sidebar.error(f"Failed to parse {p.name}: {e}")

    if not chunks:
        st.sidebar.warning("No content to index. Upload files first.")
    else:
        index = build_dense_index(chunks)
        import faiss
        faiss.write_index(index, os.path.join(INDEX_DIR, 'index.faiss'))
        with open(os.path.join(INDEX_DIR,'meta.pkl'),'wb') as f:
            pickle.dump({"chunks":chunks, "sources":sources}, f)
        st.sidebar.success(f"Indexed {len(chunks)} chunks from {len(saved_paths)} files.")

st.title("🔎 PDF + Excel Q&A (Gemini) — Persona‑aware")

persona = st.selectbox("Persona", ["Plant Operator", "Corporate Employee", "General Employee"])

persona_prompts = {
    "Plant Operator": (
        "You are a plant maintenance operator. Be safety‑first, pragmatic, and checklist‑oriented. "
        "Reference SOPs if present. Provide step‑by‑step actions, required permits, spares, and escalation rules. "
        "Prefer concise bullet points; avoid speculation. If unknown, say so."
    ),
    "Corporate Employee": (
        "You are a corporate business analyst speaking to managers. Focus on KPIs, ROI, risk, compliance, timelines, and decisions. "
        "Summarize crisply, highlight trade‑offs and assumptions, and include next steps."
    ),
    "General Employee": (
        "You are a helpful colleague. Provide clear, plain‑language instructions with minimal jargon. "
        "Offer short steps and tips to complete the task or find the information."
    ),
}

mode = st.radio("Answering mode", ["Hybrid (RAG + LLM)", "Excel SQL"], horizontal=True)
modelname = st.text_input("Gemini model", value="gemini-1.5-flash")

query = st.text_input("Your question", placeholder="e.g., What's the total savings by team in the Excel?")

def sys_prompt_with_citation(persona_key: str) -> str:
    base = persona_prompts.get(persona_key, persona_prompts["General Employee"])
    rules = (
        "Use only the provided context. If the answer is not present, say 'I couldn't find this in the uploaded files.' "
        "Cite sources with filenames in square brackets like [MyDoc.pdf]. "
        "Keep the answer targeted to the persona."
    )
    return base + " " + rules

if st.button("Ask"):
    if not query.strip():
        st.warning("Type a question first.")
    else:
        try:
            if mode == "Hybrid (RAG + LLM)":
                import faiss
                idx_path = os.path.join(INDEX_DIR,'index.faiss')
                meta_path = os.path.join(INDEX_DIR,'meta.pkl')
                if not (os.path.exists(idx_path) and os.path.exists(meta_path)):
                    st.error("Index not found. Upload files and click (Re)build Index first.")
                else:
                    index = faiss.read_index(idx_path)
                    with open(meta_path,'rb') as f:
                        meta = pickle.load(f)
                    reranked = hybrid_search(index, meta["chunks"], query, top_k=8)
                    hits = []
                    for i,score in reranked:
                        hits.append({"score": float(score), "text": meta["chunks"][i], "source": meta["sources"][i]})
                    context = "\n\n".join([f"[Source: {h['source']}]\n{h['text']}" for h in hits])

                    sys_prompt = sys_prompt_with_citation(persona)
                    user_prompt = f"Question: {query}\n\nContext:\n{context}\n\nProvide the answer with citations."
                    answer = gemini_chat_text(system_prompt=sys_prompt, user_prompt=user_prompt, model=modelname)
                    st.subheader("Answer")
                    st.write(answer)
                    with st.expander("Top context passages"):
                        for h in hits:
                            st.markdown(f"- **{h['source']}** (rerank={h['score']:.3f})\n\n{h['text'][:700]}...")

            else:  # Excel SQL
                excel_paths = [os.path.join(UPLOAD_DIR, p) for p in os.listdir(UPLOAD_DIR)
                               if pathlib.Path(p).suffix.lower() in (".xlsx",".xls")]
                if not excel_paths:
                    st.error("No Excel files uploaded. Upload .xlsx/.xls and try again.")
                else:
                    con = duckdb.connect(database=':memory:')
                    table_map = excel_to_duckdb(con, excel_paths)
                    schema_describe = []
                    for t, origin in table_map.items():
                        df = con.sql(f"SELECT * FROM {t} LIMIT 5").df()
                        schema_describe.append(f"Table {t} (from {origin}) Columns: {', '.join(map(str, df.columns))}")
                    sys_prompt = (
                        "You output only a valid DuckDB SQL query. No backticks, no explanations."
                    )
                    prompt = f"""
Available tables (with sample columns):
{chr(10).join(schema_describe)}

User question: {query}

Return ONLY the SQL:
"""
                    sql = gemini_chat_text(system_prompt=sys_prompt, user_prompt=prompt, model=modelname).strip()
                    if sql.lower().startswith("sql"):
                        sql = sql.split("\n",1)[1] if "\n" in sql else ""
                    st.code(sql, language="sql")
                    try:
                        df = con.sql(sql).df()
                        st.dataframe(df)
                        preview = df.head(10).to_markdown(index=False)
                        # Persona-aware summary
                        summary_prompt = f"SQL was:\n{sql}\n\nHere is a small sample of the result (markdown table):\n{preview}"
                        from textwrap import dedent
                        summary = gemini_chat_text(system_prompt=persona_prompts.get(persona, persona_prompts["General Employee"]),
                                                   user_prompt=summary_prompt, model=modelname)
                        st.subheader("Summary")
                        st.write(summary)
                    except Exception as e:
                        st.error(f"SQL execution failed: {e}")
        except Exception as e:
            st.error("Something went wrong. See details in the console.")
            st.exception(e)

st.sidebar.markdown("---")
if st.sidebar.button("Clear indexes"):
    shutil.rmtree(INDEX_DIR, ignore_errors=True)
    os.makedirs(INDEX_DIR, exist_ok=True)
    st.sidebar.success("Indexes cleared.")

st.caption("Gemini 1.5 (free API) • Personas • BM25 + Dense + Cross-Encoder rerank • DuckDB for Excel SQL • OCR optional")