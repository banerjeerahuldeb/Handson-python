from typing import List, Tuple
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer, CrossEncoder
from rank_bm25 import BM25Okapi

_EMB = None
_RERANK = None

def _emb():
    global _EMB
    if _EMB is None:
        _EMB = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
    return _EMB

def _cross():
    global _RERANK
    if _RERANK is None:
        _RERANK = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')
    return _RERANK

def build_dense_index(chunks: List[str]):
    embs = _emb().encode(chunks, normalize_embeddings=True, show_progress_bar=True)
    index = faiss.IndexFlatIP(embs.shape[1])
    index.add(embs.astype('float32'))
    return index

def dense_search(index, chunks: List[str], query: str, k: int = 30) -> List[Tuple[int, float]]:
    q = _emb().encode([query], normalize_embeddings=True).astype('float32')
    D, I = index.search(q, k)
    return list(zip(I[0].tolist(), D[0].tolist()))

def bm25_search(chunks: List[str], query: str, k: int = 30) -> List[Tuple[int, float]]:
    tokenized = [c.split() for c in chunks]
    bm25 = BM25Okapi(tokenized)
    scores = bm25.get_scores(query.split())
    order = np.argsort(scores)[::-1][:k]
    return [(int(i), float(scores[int(i)])) for i in order]

def hybrid_search(index, chunks: List[str], query: str, k_dense: int = 30, k_bm25: int = 30, top_k: int = 10):
    dense = dense_search(index, chunks, query, k_dense)
    bm = bm25_search(chunks, query, k_bm25)
    scores = {}
    for i, s in dense:
        scores[i] = max(scores.get(i, 0.0), s)
    for i, s in bm:
        scores[i] = max(scores.get(i, 0.0), s/100.0)
    cand = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:max(top_k*4, 20)]
    pairs = [ (query, chunks[i]) for i,_ in cand ]
    rerank_scores = _cross().predict(pairs)
    reranked = sorted(zip([i for i,_ in cand], rerank_scores), key=lambda x: x[1], reverse=True)[:top_k]
    return reranked