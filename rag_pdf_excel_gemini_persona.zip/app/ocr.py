from typing import Optional
from pdf2image import convert_from_path
import pytesseract

def ocr_pdf(path: str, max_pages: int = 100) -> str:
    """OCR first `max_pages` pages from PDF to text."""
    texts = []
    pages = convert_from_path(path, dpi=200, first_page=1, last_page=max_pages)
    for img in pages:
        txt = pytesseract.image_to_string(img)
        if txt:
            texts.append(txt)
    return "\n".join(texts)