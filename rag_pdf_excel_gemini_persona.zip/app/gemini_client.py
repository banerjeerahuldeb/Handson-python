import os
import google.generativeai as genai

def _client(model: str = "gemini-1.5-flash", system_instruction: str = None, temperature: float = 0.2, max_output_tokens: int = 1024):
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        raise RuntimeError("GEMINI_API_KEY is not set in the environment.")
    genai.configure(api_key=key)
    config = genai.GenerationConfig(temperature=temperature, max_output_tokens=max_output_tokens)
    if system_instruction:
        return genai.GenerativeModel(model_name=model, system_instruction=system_instruction, generation_config=config)
    return genai.GenerativeModel(model_name=model, generation_config=config)

def gemini_chat_text(system_prompt: str, user_prompt: str, model: str = "gemini-1.5-flash", temperature: float = 0.2, max_output_tokens: int = 1024) -> str:
    m = _client(model=model, system_instruction=system_prompt, temperature=temperature, max_output_tokens=max_output_tokens)
    resp = m.generate_content(user_prompt)
    return getattr(resp, "text", "").strip()

def gemini_text_only(prompt: str, model: str = "gemini-1.5-flash", temperature: float = 0.2, max_output_tokens: int = 1024) -> str:
    m = _client(model=model, temperature=temperature, max_output_tokens=max_output_tokens)
    resp = m.generate_content(prompt)
    return getattr(resp, "text", "").strip()