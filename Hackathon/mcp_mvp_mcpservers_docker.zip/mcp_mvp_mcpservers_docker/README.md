# PlantHelm – MCP Servers + Agent (Docker runner with Approval Gate)

## Quick start
1) Set env in a `.env` next to this file (copy from `src/.env.example` if needed).
2) Place your HR roster file and set `HR_FILE_PATH` (or rely on default mount).
3) Run:
```bash
docker compose up
```
This launches 5 MCP servers (Oracle, SQL Server, Permits API, EHS API, HR) and the Agent.

## Approval middleware
By default the agent **requires approval** for write tools:
- `workorders.create_unplanned_work_order`
- `inventory.reserve_items`
- `permits.create_permit`
- `ehs.record_jsa`

Behavior is controlled via env vars:
- `REQUIRE_APPROVAL=true|false` (default true)
- `AUTO_APPROVE=true|false` (default false)

**Flow**:
- If a write tool is called and approval is required, the agent will return a tool response with:
  ```json
  { "notice": "approval_required", "tool": "<name>", "args": {...} }
  ```
- The model will summarize and stop.
- To auto-approve (demo mode), set:
  ```
  AUTO_APPROVE=true
  ```
  and re-run `docker compose up` (or just restart the `agent` service).

## Connecting to your systems
- **Oracle**: set `ORACLE_USER`, `ORACLE_PASSWORD`, `ORACLE_DSN` (e.g., `localhost:1521/XEPDB1`)
- **SQL Server**: set `MSSQL_CONN_STR` (e.g., `Server=localhost,1433;Database=InventoryDB;User Id=sa;Password=...;Encrypt=false;`)
- **Permits API**: `PERMITS_API_BASE`, `PERMITS_API_KEY`
- **EHS API**: `EHS_API_BASE`, `EHS_API_KEY`
- **HR**: `HR_FILE_PATH` on your host will be mounted to the HR server

## Override model
Set `MODEL` (default `gpt-4o`).
