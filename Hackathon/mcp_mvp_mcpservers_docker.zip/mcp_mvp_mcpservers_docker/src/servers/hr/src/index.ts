import 'dotenv/config';
import { Server, Tool } from '@modelcontextprotocol/sdk/server';
import { z } from 'zod';
import xlsx from 'xlsx';

const server = new Server({ name: 'hr-mcp', version: '0.1.0' });
const HR_FILE_PATH = process.env.HR_FILE_PATH || './hr_roster.xlsx';

function readRoster() {
  const wb = xlsx.readFile(HR_FILE_PATH);
  const ws = wb.Sheets[wb.SheetNames[0]];
  return xlsx.utils.sheet_to_json(ws) as any[];
}

server.tool(new Tool('find_available_employees', z.object({
  date: z.string(),
  skills: z.array(z.string()).default([]),
  location: z.string()
}), async (args) => {
  const rows = readRoster();
  const out = rows.filter(r => String(r.date) === args.date && String(r.location) === args.location)
    .filter(r => args.skills.length ? args.skills.includes(String(r.skill)) : true)
    .map((r:any) => ({ employee_id: String(r.employee_id), name: String(r.name), skill: String(r.skill), shift_start: r.shift_start, shift_end: r.shift_end, date: r.date, location: r.location }));
  const seen = new Set<string>(); const uniq: any[] = [];
  for (const r of out) { if (!seen.has(r.employee_id)) { uniq.push(r); seen.add(r.employee_id); } }
  return uniq;
}));

server.connect();
console.log('[MCP] hr started');
