import 'dotenv/config';
import { Server, Tool } from '@modelcontextprotocol/sdk/server';
import { z } from 'zod';
import mssql from 'mssql';

const server = new Server({ name: 'inventory-mcp', version: '0.1.0' });
const MSSQL_CONN_STR = process.env.MSSQL_CONN_STR || '';

async function query(sql: string, params: Record<string, any> = {}) {
  const pool = await mssql.connect(MSSQL_CONN_STR);
  try {
    const req = pool.request();
    for (const [k, v] of Object.entries(params)) req.input(k, v as any);
    const res = await req.query(sql);
    return res.recordset || [];
  } finally { await pool.close(); }
}

server.tool(new Tool('get_inventory', z.object({ material_codes: z.array(z.string()) }), async (args) => {
  if (!args.material_codes.length) return [];
  const placeholders = args.material_codes.map((_, i) => f'@p{i}').join(',');
  const params:any = {};
  args.material_codes.forEach((c, i) => params['p'+i] = c);
  const rows = await query(`SELECT material_code, on_hand, uom, location FROM inv_items WHERE material_code IN (${placeholders})`, params);
  return rows;
}));

server.tool(new Tool('reserve_items', z.object({
  work_order_id: z.string(),
  reservations: z.array(z.object({ material_code: z.string(), qty: z.number() }))
}), async (args) => {
  // Demo reservation
  return { reservation_id: `RSV-${args.work_order_id}`, reserved: args.reservations };
}));

server.connect();
console.log('[MCP] inventory started');
