import 'dotenv/config';
import { Server, Tool } from '@modelcontextprotocol/sdk/server';
import { z } from 'zod';
import oracledb from 'oracledb';

const server = new Server({ name: 'workorders-mcp', version: '0.1.0' });

const ORACLE_USER = process.env.ORACLE_USER || '';
const ORACLE_PASSWORD = process.env.ORACLE_PASSWORD || '';
const ORACLE_DSN = process.env.ORACLE_DSN || 'localhost:1521/XEPDB1';

async function query(sql: string, binds: any = {}) {
  const conn = await oracledb.getConnection({ user: ORACLE_USER, password: ORACLE_PASSWORD, connectString: ORACLE_DSN });
  try { const res = await conn.execute(sql, binds, { outFormat: oracledb.OUT_FORMAT_OBJECT }); return res.rows || []; }
  finally { await conn.close(); }
}

server.tool(new Tool('find_work_orders', z.object({ asset_id: z.string(), status: z.string().optional() }), async (args) => {
  const rows = await query(
    `SELECT wo_id, asset_id, status, priority, description, TO_CHAR(target_date,'YYYY-MM-DD') target_date
       FROM ebs_work_orders
      WHERE asset_id = :asset_id
        AND (:status IS NULL OR status = :status)
      ORDER BY created_at DESC`, args);
  return rows;
}));

server.tool(new Tool('create_unplanned_work_order', z.object({
  asset_id: z.string(),
  description: z.string(),
  priority: z.string(),
  requested_by: z.string(),
  target_date: z.string()
}), async (args) => {
  await query(
    `BEGIN
       INSERT INTO ebs_work_orders(wo_id, asset_id, status, priority, description, requested_by, target_date, created_at)
       VALUES (ebs_wo_seq.NEXTVAL, :asset_id, 'New', :priority, :description, :requested_by, TO_DATE(:target_date,'YYYY-MM-DD'), SYSDATE);
     END;`, args);
  const idRow:any = (await query('SELECT MAX(wo_id) wo_id FROM ebs_work_orders WHERE asset_id=:asset_id', { asset_id: args.asset_id }))[0];
  return { work_order_id: String(idRow.WO_ID) };
}));

server.tool(new Tool('get_work_order_details', z.object({ work_order_id: z.string() }), async (args) => {
  const header:any = (await query('SELECT wo_id, asset_id, status, priority, description FROM ebs_work_orders WHERE wo_id=:work_order_id', args))[0];
  if (!header) return { error: 'WO not found' };
  const bom = await query('SELECT material_code, required_qty qty, uom FROM ebs_work_order_bom WHERE wo_id=:work_order_id', args);
  return { ...header, bom };
}));

server.connect();
console.log('[MCP] workorders started');
