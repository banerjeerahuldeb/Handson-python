import 'dotenv/config';
import { Server, Tool } from '@modelcontextprotocol/sdk/server';
import { z } from 'zod';
import { fetch } from 'undici';

const server = new Server({ name: 'permits-mcp', version: '0.1.0' });
const BASE = process.env.PERMITS_API_BASE || 'http://localhost:5000';
const KEY  = process.env.PERMITS_API_KEY || '';

async function api(path: string, init: any = {}) {
  const headers = { 'Content-Type': 'application/json', ...(KEY ? { 'Authorization': `Bearer ${KEY}` } : {}) };
  const res = await fetch(`${BASE}${path}`, { headers, ...init });
  if (!res.ok) throw new Error(`Permits API error ${res.status}`);
  return res.json();
}

server.tool(new Tool('find_permits', z.object({ work_order_id: z.string() }), async (args) => {
  return api(`/find_permits?work_order_id=${encodeURIComponent(args.work_order_id)}`);
}));

server.tool(new Tool('create_permit', z.object({
  type: z.string(),
  work_order_id: z.string(),
  location: z.string(),
  date: z.string(),
  hazards: z.array(z.string()).default([]),
  approvals: z.array(z.string()).default([])
}), async (args) => {
  return api('/create_permit', { method: 'POST', body: JSON.stringify(args) });
}));

server.connect();
console.log('[MCP] permits started');
