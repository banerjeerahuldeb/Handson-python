
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime

st.set_page_config(page_title="IncidentIntel – KPI Assurance", layout="wide")

@st.cache_data
def load_data():
    tickets = pd.read_csv("data/tickets.csv", parse_dates=["opened_at"])
    trends = pd.read_csv("data/trends.csv", parse_dates=["date"])
    exceptions = pd.read_csv("data/exceptions.csv")
    return tickets, trends, exceptions

tickets, trends, exceptions = load_data()

# ---- Sidebar Filters ----
st.sidebar.title("Filters")
min_date = tickets["opened_at"].min().date()
max_date = tickets["opened_at"].max().date()
date_range = st.sidebar.date_input("Opened date range", (min_date, max_date))

towers = ["All"] + sorted(tickets["tower"].unique().tolist())
tower = st.sidebar.selectbox("Tower", towers)

groups = ["All"] + sorted(tickets["assignment_group"].unique().tolist())
group = st.sidebar.selectbox("Group", groups)

priorities = ["All"] + sorted(tickets["priority"].unique().tolist())
priority = st.sidebar.selectbox("Priority", priorities)

analysts = ["All"] + sorted(tickets["analyst"].unique().tolist())
analyst = st.sidebar.selectbox("Analyst", analysts)

apply = st.sidebar.button("Apply Filters")

# Filter function
def apply_filters(df):
    mask = (df["opened_at"].dt.date >= date_range[0]) & (df["opened_at"].dt.date <= date_range[1])
    if tower != "All":
        mask &= df["tower"] == tower
    if group != "All":
        mask &= df["assignment_group"] == group
    if priority != "All":
        mask &= df["priority"] == priority
    if analyst != "All":
        mask &= df["analyst"] == analyst
    return df[mask]

ftix = apply_filters(tickets)

# ---- Top KPIs ----
col1, col2, col3, col4 = st.columns(4)
with col1:
    comp = (ftix["total_score"] > 80).mean()*100 if len(ftix)>0 else 0
    st.metric("Compliance % (current filter)", f"{comp:0.1f}%")
with col2:
    avg_rules = ftix["rules_score"].mean() if len(ftix)>0 else 0
    st.metric("Avg Rules Score", f"{avg_rules:0.1f}")
with col3:
    avg_llm = ftix["llm_score"].mean() if len(ftix)>0 else 0
    st.metric("Avg LLM Score", f"{avg_llm:0.1f}")
with col4:
    total = len(ftix)
    st.metric("Tickets", f"{total}")

st.divider()

# ---- Trends ----
st.subheader("Trends")
tc1, tc2, tc3 = st.columns(3)
with tc1:
    st.line_chart(trends.set_index("date")["Compliance_pct"].dropna(), height=220)
with tc2:
    st.line_chart(trends.set_index("date")["MTTA_min"], height=220)
with tc3:
    st.line_chart(trends.set_index("date")["MTTR_min"], height=220)

st.divider()

# ---- Heatmap (Compliance by Group × Type) ----
st.subheader("Compliance Heatmap (Group × Incident Type)")
if len(ftix)>0:
    ftix["is_compliant"] = ftix["total_score"] > 80
    piv = ftix.pivot_table(index="assignment_group", columns="incident_type",
                           values="is_compliant", aggfunc="mean").fillna(0)*100
    st.dataframe(piv.round(1))
else:
    st.info("No tickets in current filter.")

st.divider()

# ---- Top Exceptions ----
st.subheader("Top Exceptions")
fexc = exceptions.merge(ftix[["ticket_id"]], on="ticket_id", how="inner")
if len(fexc) == 0:
    st.info("No exceptions for current filter.")
else:
    st.dataframe(fexc.sort_values(by=["severity","age_h"], ascending=[True, False]).head(20), use_container_width=True)

st.divider()

# ---- Ticket Compliance Card (sample) ----
st.subheader("Ticket Compliance Cards")
sample = ftix.sort_values("total_score").head(5) if len(ftix)>0 else pd.DataFrame()
if len(sample)==0:
    st.info("No tickets to show.")
else:
    for _, r in sample.iterrows():
        with st.container(border=True):
            c1, c2, c3, c4, c5 = st.columns([2,1,1,1,1])
            c1.markdown(f"**{r['ticket_id']}**  |  Tower: {r['tower']}  |  Group: {r['assignment_group']}  |  Analyst: {r['analyst']}")
            c2.metric("Priority", r["priority"])
            c3.metric("Score", f"{r['total_score']:0.0f}")
            status = "At Risk" if r["total_score"] < 80 else "OK"
            c4.metric("Status", status)
            c5.metric("Age (h)", int(r["age_hours"]))

            st.progress(int(r["total_score"]))  # visual bar

            # Rule checks
            colA, colB = st.columns(2)
            with colA:
                st.markdown("**Rule Checks**")
                st.write(("✅ Acknowledged within SLA" if r["ack_sla"] else "❌ Acknowledgement SLA failed"))
                st.write(("✅ Comment cadence OK" if r["comment_cadence_ok"] else "❌ Comment cadence gap"))
                st.write(("✅ On-Hold justification" if r["on_hold_just"] else "❌ On-Hold justification missing"))
                st.write(("✅ On-Hold customer notice" if r["on_hold_notice"] else "❌ On-Hold customer notice missing"))
                st.write(("✅ Correct assignment" if r["correct_assignment"] else "❌ Assignment hygiene"))
                st.write(("✅ Correct priority" if r["correct_priority"] else "❌ Priority hygiene"))
            with colB:
                st.markdown("**Narrative Quality (LLM proxy)**")
                st.write(f"Root cause clarity: {int(r['resolution_quality'])}/5")
                st.write(f\"KB linkage: {'Yes' if r['kb_linked'] else 'No'}\")
                st.write(f\"Customer confirmation: {'Yes' if r['customer_confirmation'] else 'No'}\")
                st.write(f"LLM Score: {r['llm_score']:0.0f}")

            with st.expander("Explainability & Evidence"):
                st.caption("Synthetic evidence pointers for demo")
                st.write("- worklog#3 indicates update gap;")
                st.write("- status history shows On-Hold toggled without notice;")
                st.write("- SLA calculation window based on business hours.")
