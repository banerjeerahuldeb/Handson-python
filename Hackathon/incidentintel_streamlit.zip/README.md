# IncidentIntel – Streamlit Demo (Dummy ServiceNow Data)

This is a quick, presentation-ready Streamlit dashboard to capture **real screenshots** for the IncidentIntel prototype.

## How to run

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open the URL shown in the terminal (usually http://localhost:8501) and take screenshots.

## Pages in the demo

- **Top KPIs**: Compliance %, average Rules/LLM score, ticket count
- **Trends**: Compliance, MTTA, MTTR (synthetic)
- **Heatmap**: Compliance by Assignment Group × Incident Type
- **Top Exceptions**: Shortlist of failed rules
- **Ticket Compliance Cards**: Sample low-score tickets with rule hits/misses and narrative

> All data is synthetic and safe for demos.
