
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from datetime import datetime
from pathlib import Path

st.set_page_config(page_title="SafeMind AI", page_icon="🛡️", layout="wide")

DATA_DIR = Path(__file__).parent / "data"

@st.cache_data
def load_data():
    assets = pd.read_csv(DATA_DIR / "assets.csv")
    risks = pd.read_csv(DATA_DIR / "latest_risks.csv", parse_dates=["date","last_pm_date"])
    signals = pd.read_csv(DATA_DIR / "signals.csv", parse_dates=["date","last_pm_date"])
    sops = pd.read_csv(DATA_DIR / "sops.csv")
    events = pd.read_csv(DATA_DIR / "events.csv") if (DATA_DIR / "events.csv").exists() else pd.DataFrame(columns=["timestamp","action","asset_id","details","guardrail_passed","confidence"])
    return assets, risks, signals, sops, events

assets, risks, signals, sops, events = load_data()

# ---------------- Sidebar ----------------
st.sidebar.title("🛡️ SafeMind AI")
st.sidebar.caption("Predictive Safety Monitoring with Built-In Guardrails")

site = st.sidebar.selectbox("Site", sorted(assets["site"].unique()))
persona = st.sidebar.selectbox("Persona", ["Safety Lead", "Maintenance Planner", "Operations Supervisor", "Executive"])
show_only_high = st.sidebar.checkbox("Show High Risk only (≥ 0.7)", value=True)
st.sidebar.markdown("---")
st.sidebar.subheader("Responsible AI")
st.sidebar.checkbox("Keep human-in-the-loop for high-impact actions", value=True, disabled=True)
st.sidebar.checkbox("Log every AI action for audit", value=True, disabled=True)
st.sidebar.checkbox("No public endpoints; data stays in Azure", value=True, disabled=True)

# ---------------- Header ----------------
st.markdown("# 🧠 SafeMind AI: Predict • Prevent • Protect")
st.markdown("**Proactive safety monitoring** that learns from EBS, EHS, and ServiceNow — with guardrails baked in.")

# ---------------- KPI Cards ----------------
c1, c2, c3, c4 = st.columns(4)
site_risks = risks[risks["site"] == site]
high_risk_count = int((site_risks["risk"] >= 0.7).sum())
avg_risk = round(site_risks["risk"].mean(), 2)
open_sn = int(np.random.randint(2, 9))  # dummy
preventive_wos = int(np.random.randint(1, 6))

c1.metric("High-Risk Assets", high_risk_count)
c2.metric("Avg Risk (site)", avg_risk)
c3.metric("Open ServiceNow Tickets", open_sn)
c4.metric("Preventive Work Orders", preventive_wos)

st.markdown("### 🔥 Safety Risk Heatmap")

# Heatmap: assets vs risk
heat_df = site_risks[["asset_id","asset_name","risk"]].copy()
heat_df["Risk %"] = (heat_df["risk"] * 100).round(0)
heat_df = heat_df.sort_values("Risk %", ascending=False)
if show_only_high:
    heat_df = heat_df[heat_df["risk"] >= 0.7]

if heat_df.empty:
    st.info("No high-risk assets right now. Uncheck the filter to see all.")
else:
    fig = px.imshow(
        heat_df[["Risk %"]].T,
        labels=dict(color="Risk (%)"),
        x=heat_df["asset_name"],
        y=["Risk"],
        aspect="auto",
        color_continuous_scale="RdYlGn_r",
        zmin=0, zmax=100,
    )
    fig.update_layout(height=260, margin=dict(l=10,r=10,t=10,b=10))
    st.plotly_chart(fig, use_container_width=True)

st.markdown("### 📋 High-Risk Queue")
queue = site_risks.sort_values("risk", ascending=False)
if show_only_high:
    queue = queue[queue["risk"] >= 0.7]

for _, row in queue.iterrows():
    with st.container(border=True):
        left, right = st.columns([3,2])
        with left:
            st.markdown(f"**{row['asset_name']}** — `{row['asset_id']}`")
            st.write(f"**Area:** {row['area']} • **Criticality:** {row['criticality']}")
            st.progress(row["risk"], text=f"Risk Score: {row['risk']*100:.0f}%")
            # Signals
            sig = signals[signals["asset_id"] == row["asset_id"]].sort_values("date").tail(1).iloc[0]
            st.caption(f"Vibration: {sig['vibration_mm_s']} mm/s • Temp: {sig['temp_c']} °C • Overdue: {int(sig['overdue_days'])} days • SN Incidents(30d): {int(sig['sn_incidents_30d'])}")
        with right:
            st.markdown("**Guardrail Checks**")
            # Simple guardrail booleans
            input_safe = True  # blocked unsafe prompts (demo)
            sop_ok = True
            policy_ok = True
            confidence = 0.92 if row["asset_id"] == "PUMP-2A" else 0.86
            st.checkbox("Input Guardrail (no unsafe/invalid request)", value=input_safe, disabled=True)
            st.checkbox("Output Guardrail (SOP/policy cross-check)", value=sop_ok and policy_ok, disabled=True)
            st.slider("Confidence", 0.0, 1.0, value=float(confidence), disabled=True)
            st.caption("Low confidence => auto route to human review.")
            
            st.markdown("---")
            colA, colB, colC = st.columns(3)
            if colA.button("Create SN Ticket", key=f"sn_{row['asset_id']}"):
                st.success(f"✅ ServiceNow Ticket created: SN-{np.random.randint(10000,99999)}")
            if colB.button("Create Preventive WO", key=f"wo_{row['asset_id']}"):
                st.success(f"🛠️ Preventive Work Order created: WO-{np.random.randint(1000,9999)}")
            # SOP attach
            eq_class = assets[assets["asset_id"] == row["asset_id"]]["equipment_class"].iloc[0]
            sop = sops[sops["equipment_class"] == eq_class].head(1)
            sop_title = sop["sop_title"].iloc[0] if not sop.empty else "General Safety SOP"
            if colC.button("Attach SOP", key=f"sop_{row['asset_id']}"):
                st.info(f"📎 Attached SOP: {sop_title}")

st.markdown("### 🔎 Asset Spotlight")
spot = st.selectbox("Pick an asset to review:", site_risks["asset_name"])
sel = site_risks[site_risks["asset_name"]==spot].iloc[0]
st.write(f"**{sel['asset_name']}** — `{sel['asset_id']}` at **{sel['area']}**, criticality **{sel['criticality']}**")

# Signals table
st.caption("Latest telemetry & context (dummy)")
st.dataframe(
    signals[signals["asset_id"] == sel["asset_id"]]
        .sort_values("date", ascending=False)
        .head(5)[["date","vibration_mm_s","temp_c","overdue_days","sn_incidents_30d"]]
)

st.markdown("### 🧩 Guardrail Details")
g1, g2, g3, g4 = st.columns(4)
g1.metric("Input Guardrail", "Pass")
g2.metric("Output Guardrail", "Pass")
g3.metric("Confidence", "High")
g4.metric("Human-in-the-loop", "Enabled")

with st.expander("What guardrails do here?"):
    st.write("""
    **Input guardrails** block unsafe or irrelevant requests before processing.\n
    **Output guardrails** cross-check AI suggestions with ERP/EHS/SOP rules before action.\n
    **Confidence checks** flag low-certainty recommendations for human review.\n
    All AI actions are **logged** for audit and continuous improvement.
    """)

st.markdown("---")
st.caption("© 2025 SafeMind AI — Demo prototype for screenshots. No real system calls made.")
