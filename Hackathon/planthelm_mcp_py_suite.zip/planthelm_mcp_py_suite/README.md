# PlantHelm Python MCP Suite (5 FastAPI services + Agent)

Generated: 2025-09-25

This is a lightweight Python prototype implementing 5 FastAPI services (WorkOrders, Inventory, Permits, EHS, HR) and an Agent (FastAPI) that orchestrates them using a simple flow.

Quick steps:
1. Copy `.env.example` to `.env` and update values (OpenAI key, DB connection strings, API URLs).
2. Ensure Oracle XE, SQL Server and the .NET APIs (Permits/EHS) are available as per your environment.
3. Put an HR roster at `./data/hr_roster.xlsx` with columns: employee_id,name,skill,location,date,shift_start,shift_end
4. Build & run with Docker Compose: `docker compose up --build` (or run services locally with Python + uvicorn).
5. Agent exposes `POST /plan_and_prepare_job` on port 8110; send JSON like:
   `{ "asset_id":"PUMP-BOILER-2A","target_date":"2025-08-18","location":"REFINERY-1","needs_welding": true, "requested_by":"planner01", "priority":"High" }`
