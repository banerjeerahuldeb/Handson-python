from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os
import oracledb

app = FastAPI(title="workorders")

ORACLE_USER = os.getenv("ORACLE_USER", "MCPDEMO")
ORACLE_PASSWORD = os.getenv("ORACLE_PASSWORD", "MCPDEMO_pwd1")
ORACLE_DSN = os.getenv("ORACLE_DSN", "localhost:1521/XEPDB1")

def get_conn():
    return oracledb.connect(user=ORACLE_USER, password=ORACLE_PASSWORD, dsn=ORACLE_DSN)

class CreateWO(BaseModel):
    asset_id: str
    description: str
    priority: str
    requested_by: str
    target_date: str

@app.get("/find_work_orders")
def find_work_orders(asset_id: str, status: str = None):
    sql = """SELECT wo_id, asset_id, status, priority, description, requested_by,
           TO_CHAR(target_date,'YYYY-MM-DD') as target_date,
           TO_CHAR(created_at,'YYYY-MM-DD') as created_at
    FROM ebs_work_orders
    WHERE asset_id = :asset_id
      AND (:status IS NULL OR status = :status)
    ORDER BY created_at DESC"""
    try:
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute(sql, {"asset_id": asset_id, "status": status})
            cols = [c[0].lower() for c in cur.description]
            rows = [dict(zip(cols, row)) for row in cur.fetchall()]
        return rows
    except Exception as e:
        return {"error": str(e)}

@app.post("/create_unplanned_work_order")
def create_unplanned_work_order(payload: CreateWO):
    sql = """DECLARE
      v_wo NUMBER;
    BEGIN
      INSERT INTO ebs_work_orders (wo_id, asset_id, status, priority, description, requested_by, target_date, created_at)
      VALUES (ebs_wo_seq.NEXTVAL, :asset_id, 'New', :priority, :description, :requested_by, TO_DATE(:target_date,'YYYY-MM-DD'), SYSDATE);
      SELECT MAX(wo_id) INTO v_wo FROM ebs_work_orders WHERE asset_id = :asset_id;
      :wo_id := v_wo;
    END;"""
    try:
        with get_conn() as conn:
            cur = conn.cursor()
            wo_id_var = cur.var(int)
            cur.execute(sql, {
                "asset_id": payload.asset_id,
                "priority": payload.priority,
                "description": payload.description,
                "requested_by": payload.requested_by,
                "target_date": payload.target_date,
                "wo_id": wo_id_var
            })
            conn.commit()
            wo_id = wo_id_var.getvalue()
        return {"work_order_id": str(wo_id)}
    except Exception as e:
        return {"error": str(e)}

@app.get("/get_work_order_details")
def get_work_order_details(work_order_id: str):
    try:
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute("SELECT wo_id, asset_id, status, priority, description FROM ebs_work_orders WHERE wo_id = :wo_id", {"wo_id": work_order_id})
            header = cur.fetchone()
            if not header:
                raise HTTPException(status_code=404, detail="WO not found")
            cur.execute("SELECT material_code, required_qty, uom FROM ebs_work_order_bom WHERE wo_id = :wo_id", {"wo_id": work_order_id})
            bom = [{"material_code": r[0], "qty": float(r[1]), "uom": r[2]} for r in cur.fetchall()]
            return {
                "work_order_id": str(header[0]),
                "asset_id": header[1],
                "status": header[2],
                "priority": header[3],
                "description": header[4],
                "bom": bom
            }
    except Exception as e:
        return {"error": str(e)}

@app.get("/health")
def health():
    return {"status":"ok"}
