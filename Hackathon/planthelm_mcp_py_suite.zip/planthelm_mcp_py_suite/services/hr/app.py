from fastapi import FastAPI, HTTPException
import os, pandas as pd
app = FastAPI(title="hr")
HR_FILE_PATH = os.getenv("HR_FILE_PATH", "/data/hr_roster.xlsx")
@app.get("/find_available_employees")
def find_available_employees(date: str, skills: str = "", location: str = ""):
    skill_list = [s.strip() for s in skills.split(",")] if skills else []
    if not os.path.exists(HR_FILE_PATH):
        raise HTTPException(status_code=500, detail=f"HR file not found at {HR_FILE_PATH}")
    df = pd.read_excel(HR_FILE_PATH, dtype=str)
    df['date'] = df['date'].astype(str)
    mask = (df['date'] == date)
    if location:
        mask &= (df['location'] == location)
    if skill_list and skill_list != [""]:
        mask &= df['skill'].isin(skill_list)
    cols = ['employee_id','name','skill','shift_start','shift_end','location','date']
    try:
        results = df.loc[mask, cols].drop_duplicates(['employee_id']).to_dict(orient='records')
    except Exception:
        results = []
    return results
@app.get("/health")
def health():
    return {"status":"ok", "hr_file": HR_FILE_PATH}
