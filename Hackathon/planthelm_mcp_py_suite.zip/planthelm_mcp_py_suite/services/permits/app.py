from fastapi import FastAPI, HTTPException
import os, requests
from pydantic import BaseModel
from typing import List
app = FastAPI(title="permits")
PERMITS_API_BASE = os.getenv("PERMITS_API_BASE", "http://host.docker.internal:5000")
PERMITS_API_KEY = os.getenv("PERMITS_API_KEY", "")
def call_api(path: str, method="GET", json_body=None):
    url = f"{PERMITS_API_BASE}{path}"
    headers = {"Content-Type": "application/json"}
    if PERMITS_API_KEY:
        headers["Authorization"] = f"Bearer {PERMITS_API_KEY}"
    resp = requests.request(method, url, json=json_body, headers=headers, timeout=10)
    if not resp.ok:
        raise HTTPException(status_code=502, detail=f"Permits API error {resp.status_code}")
    return resp.json()
@app.get("/find_permits")
def find_permits(work_order_id: str):
    return call_api(f"/find_permits?work_order_id={work_order_id}")
class CreatePermit(BaseModel):
    type: str
    work_order_id: str
    location: str
    date: str
    hazards: List[str] = []
    approvals: List[str] = []
@app.post("/create_permit")
def create_permit(payload: CreatePermit):
    return call_api("/create_permit", method="POST", json_body=payload.dict())
@app.get("/health")
def health():
    return {"status":"ok", "proxied_to": PERMITS_API_BASE}
