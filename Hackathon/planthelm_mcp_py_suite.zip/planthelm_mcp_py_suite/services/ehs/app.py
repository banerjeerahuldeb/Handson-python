from fastapi import FastAPI, HTTPException
import os, requests
from typing import Dict
app = FastAPI(title="ehs")
EHS_API_BASE = os.getenv("EHS_API_BASE", "http://host.docker.internal:5001")
EHS_API_KEY = os.getenv("EHS_API_KEY", "")
def call_api(path: str, method="GET", json_body=None):
    url = f"{EHS_API_BASE}{path}"
    headers = {"Content-Type": "application/json"}
    if EHS_API_KEY:
        headers["Authorization"] = f"Bearer {EHS_API_KEY}"
    resp = requests.request(method, url, json=json_body, headers=headers, timeout=10)
    if not resp.ok:
        raise HTTPException(status_code=502, detail=f"EHS API error {resp.status_code}")
    return resp.json()
@app.post("/check_employee_safety")
def check_employee_safety(payload: Dict):
    return call_api("/check_employee_safety", method="POST", json_body=payload)
@app.get("/employees/{employee_id}/clearance")
def employee_clearance(employee_id: str, date: str):
    return call_api(f"/employees/{employee_id}/clearance?date={date}")
@app.get("/workorders/{work_order_id}/job-readiness")
def job_readiness(work_order_id: str):
    return call_api(f"/workorders/{work_order_id}/job-readiness")
@app.post("/workorders/{work_order_id}/jsa")
def record_jsa(work_order_id: str, body: Dict):
    return call_api(f"/workorders/{work_order_id}/jsa", method="POST", json_body=body)
@app.get("/health")
def health():
    return {"status":"ok", "proxied_to": EHS_API_BASE}
