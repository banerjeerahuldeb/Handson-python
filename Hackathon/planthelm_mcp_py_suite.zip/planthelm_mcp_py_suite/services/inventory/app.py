from fastapi import FastAPI
import os
import pyodbc
app = FastAPI(title="inventory")
MSSQL_CONN_STR = os.getenv("MSSQL_CONN_STR", "Driver={ODBC Driver 18 for SQL Server};Server=localhost,1433;Database=InventoryDB;Uid=sa;Pwd=Strong!Passw0rd;Encrypt=no;TrustServerCertificate=yes")
def get_conn():
    return pyodbc.connect(MSSQL_CONN_STR, autocommit=False)
@app.get("/get_inventory")
def get_inventory(material_codes: str = ""):
    codes = [c.strip() for c in material_codes.split(",") if c.strip()]
    if not codes:
        return []
    placeholders = ",".join(["?"] * len(codes))
    sql = f"SELECT material_code, on_hand, uom, location FROM inv_items WHERE material_code IN ({placeholders})"
    try:
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute(sql, codes)
            rows = [{"material_code": r[0], "on_hand": float(r[1]), "uom": r[2], "location": r[3]} for r in cur.fetchall()]
        return rows
    except Exception as e:
        return {"error": str(e)}
@app.post("/reserve_items")
def reserve_items(payload: dict):
    try:
        with get_conn() as conn:
            cur = conn.cursor()
            for r in payload.get("reservations", []):
                cur.execute("INSERT INTO inv_reservations (reservation_id, wo_id, material_code, qty) VALUES (?, ?, ?, ?)",
                            (f"RSV-{payload.get('work_order_id')}", payload.get("work_order_id"), r["material_code"], r["qty"]))
            conn.commit()
        return {"reservation_id": f"RSV-{payload.get('work_order_id')}", "reserved": payload.get("reservations", [])}
    except Exception as e:
        return {"error": str(e)}
@app.get("/health")
def health():
    return {"status":"ok"}
