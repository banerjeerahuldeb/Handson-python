import os, json, requests
from fastapi import FastAPI
from pydantic import BaseModel
import openai
openai.api_key = os.getenv("OPENAI_API_KEY")
WORKORDERS_URL = os.getenv("WORKORDERS_URL", "http://workorders:8000")
INVENTORY_URL = os.getenv("INVENTORY_URL", "http://inventory:8000")
HR_URL = os.getenv("HR_URL", "http://hr:8000")
PERMITS_URL = os.getenv("PERMITS_URL", "http://permits:8000")
EHS_URL = os.getenv("EHS_URL", "http://ehs:8000")
app = FastAPI(title="planthelm-agent")
class PlanReq(BaseModel):
    asset_id: str
    target_date: str
    location: str
    needs_welding: bool = False
    requested_by: str = "planner01"
    priority: str = "High"
def call_service(url, path, method="GET", params=None, json_body=None):
    full = f"{url}{path}"
    try:
        if method == "GET":
            r = requests.get(full, params=params, timeout=10)
        else:
            r = requests.post(full, json=json_body, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        return {"error": str(e), "url": full}
@app.post("/plan_and_prepare_job")
def plan_and_prepare(req: PlanReq):
    wos = call_service(WORKORDERS_URL, "/find_work_orders", params={"asset_id": req.asset_id, "status": "Planned"})
    if isinstance(wos, dict) and wos.get("error"):
        return {"error": "workorders error", "details": wos}
    if wos:
        return {"message": "Found existing planned WOs", "wos": wos}
    create = call_service(WORKORDERS_URL, "/create_unplanned_work_order", method="POST", json_body={
        "asset_id": req.asset_id, "description": f"Unplanned repair for {req.asset_id}", "priority": req.priority,
        "requested_by": req.requested_by, "target_date": req.target_date
    })
    if create.get("error"):
        return {"error": "create_wo_failed", "details": create}
    wo_id = create.get("work_order_id")
    details = call_service(WORKORDERS_URL, "/get_work_order_details", params={"work_order_id": wo_id})
    material_codes = ",".join([m["material_code"] for m in (details.get("bom") or [])]) if details else ""
    inv = call_service(INVENTORY_URL, "/get_inventory", params={"material_codes": material_codes})
    permit = None
    if req.needs_welding:
        permit = call_service(PERMITS_URL, "/create_permit", method="POST", json_body={
            "type": "Hot Work", "work_order_id": wo_id, "location": req.location, "date": req.target_date, "hazards": ["welding"], "approvals": ["safety_officer"]
        })
    hr = call_service(HR_URL, "/find_available_employees", params={"date": req.target_date, "skills": "welder" if req.needs_welding else "", "location": req.location})
    ehs = None
    if hr and isinstance(hr, list) and req.needs_welding:
        emp_ids = [e["employee_id"] for e in hr]
        ehs = call_service(EHS_URL, "/check_employee_safety", method="POST", json_body={"employee_ids": emp_ids, "permit_type": "Hot Work"})
    summary = {
        "work_order_created": create,
        "work_order_details": details,
        "inventory": inv,
        "permit": permit,
        "hr": hr,
        "ehs": ehs
    }
    return summary
