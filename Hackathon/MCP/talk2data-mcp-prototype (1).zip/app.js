// Talk2Data: Unified AI Operations Agent
// Application state and data management

class Talk2DataApp {
    constructor() {
        this.state = {
            workflows: [],
            approvals: [],
            auditLog: [
                {
                    timestamp: '3:00 PM',
                    action: 'System initialized',
                    user: 'System'
                }
            ],
            mcpServers: {
                erp: { name: 'Oracle EBS ERP', status: 'Connected', capabilities: ['work_orders', 'maintenance_history', 'asset_management'] },
                inventory: { name: 'Inventory Management', status: 'Connected', capabilities: ['parts_lookup', 'stock_levels', 'procurement'] },
                permit: { name: 'Permit Management', status: 'Connected', capabilities: ['permit_creation', 'safety_checks', 'approval_workflow'] },
                hr: { name: 'HR System', status: 'Connected', capabilities: ['employee_lookup', 'availability_check', 'scheduling'] }
            }
        };
        
        // Sample data from the provided JSON
        this.data = {
            equipment: {
                "PUMP-BOILER-2A": {
                    name: "Primary Boiler Feed Pump 2A",
                    location: "Boiler House Level 2",
                    type: "Centrifugal Pump",
                    criticality: "High",
                    lastMaintenance: "2025-07-15",
                    nextScheduled: "2025-09-15"
                },
                "PUMP-SLURRY-3B": {
                    name: "Slurry Transfer Pump 3B",
                    location: "Processing Plant",
                    type: "Slurry Pump",
                    criticality: "Medium",
                    lastMaintenance: "2025-08-01",
                    nextScheduled: "2025-10-01"
                }
            },
            inventory: {
                "GASKET-BOILER-FEED": {
                    partNumber: "GAS-BF-001",
                    description: "High-temp Boiler Feed Gasket Set",
                    quantity: 5,
                    location: "Warehouse A-15",
                    supplier: "Industrial Seals Inc",
                    leadTime: "3-5 days"
                },
                "WELD-ROD-316SS": {
                    partNumber: "WR-316-001",
                    description: "316 Stainless Steel Welding Rod",
                    quantity: 25,
                    location: "Welding Shop",
                    supplier: "MetalWorks Supply",
                    leadTime: "Same day"
                },
                "PUMP-IMPELLER-2A": {
                    partNumber: "IMP-2A-001",
                    description: "Replacement Impeller for Pump 2A",
                    quantity: 1,
                    location: "Critical Parts Storage",
                    supplier: "Pump Specialists Ltd",
                    leadTime: "7-10 days"
                }
            },
            employees: {
                "EMP-001": {
                    name: "John Martinez",
                    role: "Senior Maintenance Technician",
                    certifications: ["Hot Work Permit", "Confined Space", "Electrical Safety"],
                    availability: {
                        "2025-08-16": "Available",
                        "2025-08-17": "On Leave",
                        "2025-08-18": "Available"
                    }
                },
                "EMP-002": {
                    name: "Sarah Chen",
                    role: "Mechanical Engineer",
                    certifications: ["Hot Work Permit", "Pressure Vessel", "NDT Level 2"],
                    availability: {
                        "2025-08-16": "Available",
                        "2025-08-17": "Available",
                        "2025-08-18": "Training"
                    }
                },
                "EMP-003": {
                    name: "Mike Thompson",
                    role: "Welder Specialist",
                    certifications: ["AWS Certified", "Hot Work Permit", "Pressure Welding"],
                    availability: {
                        "2025-08-16": "Night Shift",
                        "2025-08-17": "Available",
                        "2025-08-18": "Available"
                    }
                }
            }
        };
        
        this.currentWorkflowId = 0;
        this.currentApprovalId = 0;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.renderServerStatus();
        this.updateCounts();
    }
    
    setupEventListeners() {
        // Chat input handling
        const chatInput = document.getElementById('chatInput');
        const sendButton = document.getElementById('sendMessage');
        
        sendButton.addEventListener('click', () => this.sendMessage());
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Clear chat
        document.getElementById('clearChat').addEventListener('click', () => {
            const chatMessages = document.getElementById('chatMessages');
            chatMessages.innerHTML = `
                <div class="message agent-message">
                    <div class="message-content">
                        <div class="message-avatar">AI</div>
                        <div class="message-text">
                            <p>Chat cleared. How can I help you with operations today?</p>
                        </div>
                    </div>
                    <div class="message-timestamp">${this.getCurrentTime()}</div>
                </div>
            `;
            this.addAuditEntry('Chat cleared', 'User');
        });
        
        // Clear audit
        document.getElementById('clearAudit').addEventListener('click', () => {
            this.state.auditLog = [
                {
                    timestamp: this.getCurrentTime(),
                    action: 'Audit log cleared',
                    user: 'User'
                }
            ];
            this.renderAuditLog();
        });
        
        // Modal handling
        const modalOverlay = document.getElementById('modalOverlay');
        const modalClose = document.getElementById('modalClose');
        const modalCancel = document.getElementById('modalCancel');
        
        [modalOverlay, modalClose, modalCancel].forEach(el => {
            el.addEventListener('click', () => this.closeModal());
        });
    }
    
    getCurrentTime() {
        const now = new Date();
        return now.toLocaleTimeString('en-US', { 
            hour: 'numeric', 
            minute: '2-digit',
            hour12: true 
        });
    }
    
    renderServerStatus() {
        const container = document.getElementById('serverStatus');
        container.innerHTML = '';
        
        Object.entries(this.state.mcpServers).forEach(([key, server]) => {
            const serverCard = document.createElement('div');
            serverCard.className = 'server-card';
            
            serverCard.innerHTML = `
                <div class="server-status ${server.status.toLowerCase()}"></div>
                <div class="server-info">
                    <h3>${server.name}</h3>
                    <div class="server-capabilities">${server.capabilities.join(', ')}</div>
                </div>
            `;
            
            container.appendChild(serverCard);
        });
    }
    
    addMessage(content, isUser = false, delay = 0) {
        setTimeout(() => {
            const chatMessages = document.getElementById('chatMessages');
            const messageEl = document.createElement('div');
            messageEl.className = `message ${isUser ? 'user-message' : 'agent-message'}`;
            
            messageEl.innerHTML = `
                <div class="message-content">
                    <div class="message-avatar">${isUser ? 'U' : 'AI'}</div>
                    <div class="message-text">
                        ${content}
                    </div>
                </div>
                <div class="message-timestamp">${this.getCurrentTime()}</div>
            `;
            
            chatMessages.appendChild(messageEl);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, delay);
    }
    
    sendMessage() {
        const input = document.getElementById('chatInput');
        const message = input.value.trim();
        
        if (!message) return;
        
        // Add user message
        this.addMessage(`<p>${message}</p>`, true);
        input.value = '';
        
        this.addAuditEntry(`User message: "${message.substring(0, 50)}${message.length > 50 ? '...' : ''}"`, 'User');
        
        // Process the message
        this.processMessage(message);
    }
    
    processMessage(message) {
        // Check if this is the demo scenario
        const isDemoScenario = message.toLowerCase().includes('pump-boiler-2a') && 
                              (message.toLowerCase().includes('corrosion') || message.toLowerCase().includes('leakage'));
        
        if (isDemoScenario) {
            this.handleDemoScenario(message);
        } else {
            // Generic AI response
            this.addMessage(`
                <p>I understand you're reporting: "${message}"</p>
                <p>Let me analyze this situation and check our systems for relevant information...</p>
            `, false, 1000);
            
            this.addMessage(`
                <p>For the best demonstration of my capabilities, try the example scenario:</p>
                <p><em>"I checked the pump PUMP-BOILER-2A having a corrosion and chances of leakage is very high"</em></p>
            `, false, 3000);
        }
    }
    
    handleDemoScenario(message) {
        // Add initial response
        this.addMessage(`
            <p>🔍 Analyzing corrosion issue on PUMP-BOILER-2A...</p>
            <p>This is a high-criticality equipment. Let me orchestrate a comprehensive response workflow.</p>
        `, false, 1000);
        
        // Create the main workflow immediately
        setTimeout(() => {
            const workflowId = this.createWorkflow('Emergency Maintenance - PUMP-BOILER-2A Corrosion', 'in-progress');
            
            // Step 1: Query ERP
            setTimeout(() => {
                this.simulateMCPQuery('erp', 'Checking existing maintenance records...');
                
                setTimeout(() => {
                    this.addMessage(`
                        <p>📋 <strong>ERP Query Results:</strong></p>
                        <p>• Last maintenance: July 15, 2025</p>
                        <p>• Next scheduled: September 15, 2025 (30 days ahead)</p>
                        <p>• No active work orders found for PUMP-BOILER-2A</p>
                        <p>• Criticality: HIGH - Immediate attention required</p>
                    `, false);
                    
                    this.updateWorkflowStep(workflowId, 0, 'completed');
                }, 1500);
                
                // Step 2: Create approval for work order
                setTimeout(() => {
                    this.addMessage(`
                        <p>⚠️ <strong>Recommendation:</strong> Create unplanned work order for immediate inspection and repair.</p>
                    `, false);
                    
                    this.createApproval(
                        'Create Emergency Work Order',
                        'Create unplanned work order WO-2025-0856 for PUMP-BOILER-2A corrosion repair',
                        () => this.approveWorkOrder(workflowId)
                    );
                }, 2500);
            }, 1000);
            
            // Step 3: Check inventory
            setTimeout(() => {
                this.simulateMCPQuery('inventory', 'Checking parts availability...');
                
                setTimeout(() => {
                    this.addMessage(`
                        <p>📦 <strong>Inventory Check Results:</strong></p>
                        <p>• Gasket Set (GAS-BF-001): 5 units available in Warehouse A-15</p>
                        <p>• Welding Rod 316SS (WR-316-001): 25 units available in Welding Shop</p>
                        <p>• Pump Impeller 2A (IMP-2A-001): 1 unit in Critical Parts Storage</p>
                        <p>✅ All critical parts available for immediate repair</p>
                    `, false);
                    
                    this.updateWorkflowStep(workflowId, 1, 'completed');
                }, 1500);
            }, 4000);
            
            // Step 4: Check permits
            setTimeout(() => {
                this.simulateMCPQuery('permit', 'Evaluating safety permit requirements...');
                
                setTimeout(() => {
                    this.addMessage(`
                        <p>🛡️ <strong>Safety Assessment:</strong></p>
                        <p>• Hot work permit required (welding/cutting operations)</p>
                        <p>• Confined space entry protocols needed</p>
                        <p>• Lock-out/Tag-out procedures mandatory</p>
                    `, false);
                    
                    this.createApproval(
                        'Issue Hot Work Permit',
                        'Issue hot work permit HW-2025-0234 for welding operations on PUMP-BOILER-2A',
                        () => this.approvePermit(workflowId)
                    );
                    
                    this.updateWorkflowStep(workflowId, 2, 'completed');
                }, 1500);
            }, 7000);
            
            // Step 5: Check HR
            setTimeout(() => {
                this.simulateMCPQuery('hr', 'Checking employee availability...');
                
                setTimeout(() => {
                    this.addMessage(`
                        <p>👥 <strong>Employee Availability (Next 3 Days):</strong></p>
                        <p>• <strong>John Martinez</strong> (Senior Tech): Available Aug 16 & 18</p>
                        <p>• <strong>Sarah Chen</strong> (Mechanical Eng): Available Aug 16 & 17</p>
                        <p>• <strong>Mike Thompson</strong> (Welder): Available Aug 17 & 18</p>
                    `, false);
                    
                    // Step 6: Provide scheduling recommendation
                    setTimeout(() => {
                        this.addMessage(`
                            <p>📅 <strong>Optimal Scheduling Recommendation:</strong></p>
                            <p>• <strong>August 17, 2025</strong> - Best availability</p>
                            <p>• Team: Sarah Chen (Lead), Mike Thompson (Welder)</p>
                            <p>• Duration: 4-6 hours</p>
                            <p>• Start time: 8:00 AM (after hot work permit approval)</p>
                        `, false);
                        
                        this.createApproval(
                            'Schedule Emergency Maintenance',
                            'Schedule maintenance team for August 17, 2025 at 8:00 AM',
                            () => this.approveScheduling(workflowId)
                        );
                        
                        this.updateWorkflowStep(workflowId, 3, 'completed');
                    }, 1000);
                }, 1500);
            }, 10000);
            
        }, 500);
        
        this.addAuditEntry('Demo scenario workflow initiated', 'AI Agent');
    }
    
    simulateMCPQuery(server, message) {
        // Find the correct server card and temporarily show as busy
        const serverCards = document.querySelectorAll('.server-card');
        const serverNames = ['Oracle EBS ERP', 'Inventory Management', 'Permit Management', 'HR System'];
        const serverIndex = ['erp', 'inventory', 'permit', 'hr'].indexOf(server);
        
        if (serverIndex >= 0 && serverCards[serverIndex]) {
            const status = serverCards[serverIndex].querySelector('.server-status');
            const originalClass = status.className;
            
            // Show as busy (orange)
            status.className = 'server-status busy';
            
            setTimeout(() => {
                status.className = originalClass;
            }, 1500);
        }
        
        this.addMessage(`<p>🔄 MCP/${server.toUpperCase()}: ${message}</p>`, false, 200);
        this.addAuditEntry(`MCP query: ${server} - ${message}`, 'AI Agent');
    }
    
    createWorkflow(title, status = 'pending') {
        const id = ++this.currentWorkflowId;
        const workflow = {
            id,
            title,
            status,
            progress: status === 'pending' ? 0 : 25,
            steps: [
                { name: 'ERP Query', status: 'in-progress' },
                { name: 'Inventory Check', status: 'pending' },
                { name: 'Safety Assessment', status: 'pending' },
                { name: 'Resource Planning', status: 'pending' }
            ]
        };
        
        this.state.workflows.push(workflow);
        this.renderWorkflows();
        this.updateCounts();
        
        this.addAuditEntry(`Workflow created: ${title}`, 'AI Agent');
        
        return id;
    }
    
    updateWorkflowStep(workflowId, stepIndex, status) {
        const workflow = this.state.workflows.find(w => w.id === workflowId);
        if (workflow && workflow.steps[stepIndex]) {
            workflow.steps[stepIndex].status = status;
            
            // Update next step to in-progress
            if (stepIndex + 1 < workflow.steps.length) {
                workflow.steps[stepIndex + 1].status = 'in-progress';
            }
            
            // Update overall progress
            const completedSteps = workflow.steps.filter(s => s.status === 'completed').length;
            workflow.progress = (completedSteps / workflow.steps.length) * 100;
            
            this.renderWorkflows();
        }
    }
    
    createApproval(title, description, onApprove) {
        const id = ++this.currentApprovalId;
        const approval = {
            id,
            title,
            description,
            onApprove
        };
        
        this.state.approvals.push(approval);
        this.renderApprovals();
        this.updateCounts();
        
        this.addAuditEntry(`Approval request: ${title}`, 'AI Agent');
    }
    
    approveWorkOrder(workflowId) {
        this.addMessage(`
            <p>✅ <strong>Work Order WO-2025-0856 Created</strong></p>
            <p>Emergency maintenance work order has been approved and created in the ERP system.</p>
        `, false, 500);
        
        this.updateWorkflowProgress(workflowId, 50);
        this.removeApproval(1);
        this.addAuditEntry('Work order WO-2025-0856 approved', 'User');
    }
    
    approvePermit(workflowId) {
        this.addMessage(`
            <p>✅ <strong>Hot Work Permit HW-2025-0234 Issued</strong></p>
            <p>Safety permits approved. Team authorized for welding operations.</p>
        `, false, 500);
        
        this.updateWorkflowProgress(workflowId, 75);
        this.removeApproval(2);
        this.addAuditEntry('Hot work permit HW-2025-0234 approved', 'User');
    }
    
    approveScheduling(workflowId) {
        this.addMessage(`
            <p>✅ <strong>Maintenance Scheduled</strong></p>
            <p>Emergency maintenance scheduled for August 17, 2025 at 8:00 AM.</p>
            <p>Team notifications sent. All systems coordinated.</p>
        `, false, 500);
        
        this.updateWorkflowProgress(workflowId, 100, 'completed');
        this.removeApproval(3);
        this.addAuditEntry('Emergency maintenance scheduled for Aug 17', 'User');
        
        setTimeout(() => {
            this.addMessage(`
                <p>🎯 <strong>Workflow Complete!</strong></p>
                <p>All systems coordinated successfully:</p>
                <p>• Work order created in ERP</p>
                <p>• Parts reserved in inventory</p>
                <p>• Safety permits issued</p>
                <p>• Maintenance team scheduled</p>
                <p>Emergency response time: <strong>2 minutes</strong> from issue report to full coordination.</p>
            `, false);
        }, 1000);
    }
    
    updateWorkflowProgress(workflowId, progress, status = null) {
        const workflow = this.state.workflows.find(w => w.id === workflowId);
        if (workflow) {
            workflow.progress = progress;
            if (status) workflow.status = status;
            this.renderWorkflows();
        }
    }
    
    removeApproval(approvalId) {
        this.state.approvals = this.state.approvals.filter(a => a.id !== approvalId);
        this.renderApprovals();
        this.updateCounts();
    }
    
    renderWorkflows() {
        const container = document.getElementById('workflowContainer');
        
        if (this.state.workflows.length === 0) {
            container.innerHTML = '<div class="empty-state"><p>No active workflows. Start by describing an operational issue in the chat.</p></div>';
            return;
        }
        
        container.innerHTML = this.state.workflows.map(workflow => `
            <div class="workflow-item" onclick="app.showWorkflowDetails(${workflow.id})">
                <div class="workflow-header">
                    <h4 class="workflow-title">${workflow.title}</h4>
                    <span class="workflow-status ${workflow.status}">${workflow.status.replace('-', ' ')}</span>
                </div>
                <div class="workflow-progress">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${workflow.progress}%"></div>
                    </div>
                    <small>${workflow.progress}% complete</small>
                </div>
            </div>
        `).join('');
    }
    
    renderApprovals() {
        const container = document.getElementById('approvalContainer');
        
        if (this.state.approvals.length === 0) {
            container.innerHTML = '<div class="empty-state"><p>No pending approvals.</p></div>';
            return;
        }
        
        container.innerHTML = this.state.approvals.map(approval => `
            <div class="approval-item">
                <h4 class="approval-title">${approval.title}</h4>
                <p class="approval-description">${approval.description}</p>
                <div class="approval-actions">
                    <button class="btn btn--outline btn--sm" onclick="app.rejectApproval(${approval.id})">Reject</button>
                    <button class="btn btn--primary btn--sm" onclick="app.approveAction(${approval.id})">Approve</button>
                </div>
            </div>
        `).join('');
    }
    
    approveAction(approvalId) {
        const approval = this.state.approvals.find(a => a.id === approvalId);
        if (approval && approval.onApprove) {
            approval.onApprove();
        }
    }
    
    rejectApproval(approvalId) {
        const approval = this.state.approvals.find(a => a.id === approvalId);
        if (approval) {
            this.addMessage(`
                <p>❌ <strong>Approval Rejected:</strong> ${approval.title}</p>
                <p>Please provide alternative instructions or modifications.</p>
            `, false);
            
            this.removeApproval(approvalId);
            this.addAuditEntry(`Approval rejected: ${approval.title}`, 'User');
        }
    }
    
    renderAuditLog() {
        const container = document.getElementById('auditContainer');
        container.innerHTML = this.state.auditLog.map(entry => `
            <div class="audit-entry">
                <div class="audit-timestamp">${entry.timestamp}</div>
                <div class="audit-action">${entry.action}</div>
                <div class="audit-user">${entry.user}</div>
            </div>
        `).join('');
        
        // Scroll to top to show latest entry
        container.scrollTop = 0;
    }
    
    addAuditEntry(action, user) {
        this.state.auditLog.unshift({
            timestamp: this.getCurrentTime(),
            action,
            user
        });
        
        // Keep only last 50 entries
        if (this.state.auditLog.length > 50) {
            this.state.auditLog = this.state.auditLog.slice(0, 50);
        }
        
        this.renderAuditLog();
    }
    
    updateCounts() {
        document.getElementById('workflowCount').textContent = 
            `${this.state.workflows.length} Active`;
        document.getElementById('approvalCount').textContent = 
            `${this.state.approvals.length} Pending`;
    }
    
    showWorkflowDetails(workflowId) {
        const workflow = this.state.workflows.find(w => w.id === workflowId);
        if (!workflow) return;
        
        const modal = document.getElementById('workflowModal');
        const title = document.getElementById('modalTitle');
        const body = document.getElementById('modalBody');
        
        title.textContent = workflow.title;
        body.innerHTML = `
            <div class="workflow-details">
                <p><strong>Status:</strong> ${workflow.status.replace('-', ' ')}</p>
                <p><strong>Progress:</strong> ${workflow.progress}%</p>
                <h4>Workflow Steps:</h4>
                <ul>
                    ${workflow.steps.map(step => `
                        <li class="step-${step.status}">
                            ${step.name} - <span class="status status--${step.status === 'completed' ? 'success' : step.status === 'in-progress' ? 'warning' : 'info'}">${step.status}</span>
                        </li>
                    `).join('')}
                </ul>
            </div>
        `;
        
        modal.classList.remove('hidden');
    }
    
    closeModal() {
        document.getElementById('workflowModal').classList.add('hidden');
    }
}

// Initialize the application
let app;

document.addEventListener('DOMContentLoaded', () => {
    app = new Talk2DataApp();
    
    // Add some initial demo hints after a delay
    setTimeout(() => {
        app.addMessage(`
            <p>💡 <strong>Demo Ready!</strong></p>
            <p>Try the sample scenario to see the full AI orchestration capabilities:</p>
            <p><strong>"I checked the pump PUMP-BOILER-2A having a corrosion and chances of leakage is very high"</strong></p>
            <p>This will demonstrate automatic querying of all MCP servers and workflow orchestration.</p>
        `, false);
    }, 2000);
});