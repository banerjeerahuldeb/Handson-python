MCP-native 5 servers + agent. See agent/src/index.ts for orchestration.
