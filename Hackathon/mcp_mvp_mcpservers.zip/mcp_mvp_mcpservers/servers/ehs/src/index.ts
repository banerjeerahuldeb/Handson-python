import 'dotenv/config';
import { Server, Tool } from '@modelcontextprotocol/sdk/server';
import { z } from 'zod';
import { fetch } from 'undici';

const server = new Server({ name: 'ehs-mcp', version: '0.1.0' });
const BASE = process.env.EHS_API_BASE || 'http://localhost:5001';
const KEY  = process.env.EHS_API_KEY || '';

async function api(path: string, init: any = {}) {
  const headers = { 'Content-Type': 'application/json', ...(KEY ? { 'Authorization': `Bearer ${KEY}` } : {}) };
  const res = await fetch(`${BASE}${path}`, { headers, ...init });
  if (!res.ok) throw new Error(`EHS API error ${res.status}`);
  return res.json();
}

server.tool(new Tool('check_employee_clearance', z.object({
  employee_id: z.string(),
  date: z.string()
}), async (args) => {
  return api(`/employees/${encodeURIComponent(args.employee_id)}/clearance?date=${encodeURIComponent(args.date)}`);
}));

server.tool(new Tool('verify_job_readiness', z.object({ work_order_id: z.string() }), async (args) => {
  return api(`/workorders/${encodeURIComponent(args.work_order_id)}/job-readiness`);
}));

server.tool(new Tool('record_jsa', z.object({
  work_order_id: z.string(),
  hazards: z.array(z.string()),
  mitigations: z.array(z.string()),
  performed_by: z.string(),
  date: z.string()
}), async (args) => {
  return api(`/workorders/${encodeURIComponent(args.work_order_id)}/jsa`, { method: 'POST', body: JSON.stringify(args) });
}));

server.connect();
console.log('[MCP] ehs started');
