import 'dotenv/config';
import { Client as McpClient } from '@modelcontextprotocol/sdk/client';
import { connectStdio } from '@modelcontextprotocol/sdk/client/stdio';
import { spawn } from 'child_process';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const servers = {
  workorders: { cmd: 'npm', args: ['run','dev','-w','servers/workorders'] },
  inventory:  { cmd: 'npm', args: ['run','dev','-w','servers/inventory'] },
  permits:    { cmd: 'npm', args: ['run','dev','-w','servers/permits'] },
  ehs:        { cmd: 'npm', args: ['run','dev','-w','servers/ehs'] },
  hr:         { cmd: 'npm', args: ['run','dev','-w','servers/hr'] },
};

async function startServer(name: string) {
  const p = spawn(servers[name].cmd, servers[name].args, { stdio: ['pipe','pipe','pipe'] });
  const conn = connectStdio({ input: p.stdout!, output: p.stdin! });
  const client = new McpClient(conn);
  await client.initialize({ name: `agent-client-${name}`, version: '0.1.0' });
  return { process: p, client };
}

async function main() {
  const conns = await Promise.all(Object.keys(servers).map(startServer));
  const named: Record<string, McpClient> = {};
  Object.keys(servers).forEach((k, i) => named[k] = conns[i].client);

  const toolMap: Record<string, string> = {};
  const toolsForOpenAI: any[] = [];
  for (const [name, client] of Object.entries(named)) {
    const tools = await client.listTools();
    for (const t of tools.tools) {
      const toolName = `${name}.${t.name}`;
      toolMap[toolName] = name;
      toolsForOpenAI.push({
        type: 'function',
        function: { name: toolName, description: `${name}::${t.name}`, parameters: t.inputSchema || { type: 'object', properties: {} } }
      });
    }
  }

  const messages: any[] = [
    { role: 'system', content: 'You are PlantHelm, a maintenance planner assistant. Read-first, confirm-then-write. Use the appropriate tools.' },
    { role: 'user', content: 'PUMP-BOILER-2A has corrosion; plan a hot work repair on 2025-08-18 at REFINERY-1.' }
  ];

  while (true) {
    const resp = await openai.chat.completions.create({ model: process.env.MODEL || 'gpt-4o', messages, tools: toolsForOpenAI, tool_choice: 'auto' });
    const msg: any = resp.choices[0].message;
    if (!msg.tool_calls?.length) {
      console.log('\n=== FINAL ===\n', msg.content);
      break;
    }
    for (const call of msg.tool_calls) {
      const [serverName, pureTool] = call.function.name.split('.', 2);
      const args = call.function.arguments ? JSON.parse(call.function.arguments) : {};
      const client = named[serverName];
      const result = await client.callTool({ name: pureTool, arguments: args });
      messages.push({ role: 'tool', tool_call_id: call.id, name: call.function.name, content: JSON.stringify(result) });
    }
  }
  process.exit(0);
}

main().catch(e => { console.error(e); process.exit(1); });
