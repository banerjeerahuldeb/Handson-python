using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

var permits = new List<Dictionary<string, object>>();

app.MapGet("/find_permits", (string work_order_id) => {
    var result = permits.Where(p => (string)p["work_order_id"] == work_order_id).ToList();
    return Results.Ok(result);
});

app.MapPost("/create_permit", async (HttpRequest req) => {
    var payload = await JsonSerializer.DeserializeAsync<Dictionary<string, object>>(req.Body);
    var id = Guid.NewGuid().ToString();
    var permit = new Dictionary<string, object>(payload!)
    {
        ["permit_id"] = id,
        ["status"] = "Draft",
        ["created_at"] = DateTime.UtcNow
    };
    permits.Add(permit);
    return Results.Ok(new { permit_id = id });
});

app.Run();
