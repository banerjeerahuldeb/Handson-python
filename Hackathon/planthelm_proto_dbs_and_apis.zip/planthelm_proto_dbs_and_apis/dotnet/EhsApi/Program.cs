using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

var ehs = new Dictionary<string, Dictionary<string, object>> {
    ["E101"] = new() { ["ppe_ok"] = true,  ["hot_work_cert_valid"] = true,  ["last_gas_test"] = "2025-08-12" },
    ["E102"] = new() { ["ppe_ok"] = true,  ["hot_work_cert_valid"] = false, ["last_gas_test"] = "2025-08-01" },
    ["E103"] = new() { ["ppe_ok"] = true,  ["hot_work_cert_valid"] = true,  ["last_gas_test"] = "2025-08-15" }
};

app.MapPost("/check_employee_safety", async (HttpRequest req) => {
    using var sr = new StreamReader(req.Body);
    var body = await sr.ReadToEndAsync();
    var data = JsonSerializer.Deserialize<CheckReq>(body);
    var output = new Dictionary<string, object?>();
    foreach (var id in data!.employee_ids) {
        var rec = ehs.ContainsKey(id) ? ehs[id] : new() { ["ppe_ok"] = false, ["hot_work_cert_valid"] = false };
        var eligible = data.permit_type.ToLower() == "hot work"
            ? (bool)rec["ppe_ok"]! && (bool)rec["hot_work_cert_valid"]!
            : (bool)rec["ppe_ok"]!;
        output[id] = new { rec["ppe_ok"], rec["hot_work_cert_valid"], eligible };
    }
    return Results.Ok(output);
});

app.MapGet("/employees/{id}/clearance", (string id, string date) => {
    var rec = ehs.ContainsKey(id) ? ehs[id] : new() { ["ppe_ok"] = false, ["hot_work_cert_valid"] = false };
    var eligible = (bool)rec["ppe_ok"]! && (bool)rec["hot_work_cert_valid"]!;
    return Results.Ok(new { employee_id = id, date, eligible, rec });
});

app.MapGet("/workorders/{id}/job-readiness", (string id) => Results.Ok(new { work_order_id = id, prerequisites_met = true, checklist = new [] {"PPE", "Permit Draft", "Gas Test Scheduled"} }));
app.MapPost("/workorders/{id}/jsa", (string id, HttpRequest req) => Results.Ok(new { work_order_id = id, recorded = true }));

app.Run();

public record CheckReq(string[] employee_ids, string permit_type);
