BEGIN EXECUTE IMMEDIATE 'DROP TABLE ebs_work_order_bom'; EXCEPTION WHEN OTHERS THEN NULL; END;/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE ebs_work_orders'; EXCEPTION WHEN OTHERS THEN NULL; END;/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE ebs_assets'; EXCEPTION WHEN OTHERS THEN NULL; END;/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE ebs_wo_seq'; EXCEPTION WHEN OTHERS THEN NULL; END;/

CREATE TABLE ebs_assets (asset_id VARCHAR2(64) PRIMARY KEY, description VARCHAR2(200), location VARCHAR2(100));
CREATE TABLE ebs_work_orders (wo_id NUMBER PRIMARY KEY, asset_id VARCHAR2(64) REFERENCES ebs_assets(asset_id), status VARCHAR2(20) CHECK (status IN ('New','Planned','InProgress','Completed','Canceled')), priority VARCHAR2(10), description VARCHAR2(400), requested_by VARCHAR2(100), target_date DATE, created_at DATE DEFAULT SYSDATE);
CREATE SEQUENCE ebs_wo_seq START WITH 1001 INCREMENT BY 1 NOCACHE;
CREATE TABLE ebs_work_order_bom (wo_id NUMBER REFERENCES ebs_work_orders(wo_id), material_code VARCHAR2(64), required_qty NUMBER(18,3), uom VARCHAR2(12), CONSTRAINT ebs_wobom_pk PRIMARY KEY (wo_id, material_code));

INSERT INTO ebs_assets (asset_id, description, location) VALUES ('PUMP-BOILER-2A','Boiler feed pump 2A','REFINERY-1');
INSERT INTO ebs_work_orders (wo_id, asset_id, status, priority, description, requested_by, target_date, created_at) VALUES (ebs_wo_seq.NEXTVAL, 'PUMP-BOILER-2A', 'Planned', 'Medium', 'Annual inspection', 'planner00', TO_DATE('2025-08-01','YYYY-MM-DD'), SYSDATE);
INSERT INTO ebs_work_order_bom (wo_id, material_code, required_qty, uom) SELECT wo_id, 'ELEC-ROD-7018', 5, 'kg' FROM ebs_work_orders WHERE description='Annual inspection';
COMMIT;
