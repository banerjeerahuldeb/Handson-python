IF OBJECT_ID('dbo.inv_reservations','U') IS NOT NULL DROP TABLE dbo.inv_reservations;
IF OBJECT_ID('dbo.inv_items','U') IS NOT NULL DROP TABLE dbo.inv_items;

CREATE TABLE dbo.inv_items (material_code VARCHAR(64) NOT NULL PRIMARY KEY, on_hand DECIMAL(18,3) NOT NULL, uom VARCHAR(12) NOT NULL, location VARCHAR(50) NOT NULL);
CREATE TABLE dbo.inv_reservations (reservation_id VARCHAR(64) NOT NULL, wo_id VARCHAR(32) NOT NULL, material_code VARCHAR(64) NOT NULL, qty DECIMAL(18,3) NOT NULL, reserved_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME());

INSERT INTO dbo.inv_items(material_code,on_hand,uom,location) VALUES
('ELEC-ROD-7018', 120, 'kg', 'WH1'),
('GLOVES-HOT',     50, 'pair','WH2'),
('FLANGE-2IN-SS',   8, 'ea',  'WH1');
