# PlantHelm – Local DBs + APIs Kit
(generated 2025-09-14)

## What you get
- seeds/oracle_ddl_seed.sql — Oracle XE: Assets + Work Orders + BOM (+seed)
- seeds/sqlserver_ddl_seed.sql — SQL Server: Inventory + Reservations (+seed)
- dotnet/PermitsApi — .NET 8 minimal API (in-memory)
- dotnet/EhsApi — .NET 8 minimal API (in-memory)

## Prereqs
- Docker, .NET 8 SDK
- Oracle client / SQL Server client optional

## Run DBs (containers)
### Oracle XE
docker run -d --name oracle-xe -p 1521:1521 -p 5500:5500 \
  -e ORACLE_PASSWORD=Oradoc_pwd1 -e APP_USER=MCPDEMO -e APP_USER_PASSWORD=MCPDEMO_pwd1 gvenzl/oracle-xe:21-slim

### SQL Server
docker run -d --name sqlserver -p 1433:1433 -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=Strong!Passw0rd" mcr.microsoft.com/mssql/server:2022-latest

## Seed DBs
### Oracle
Connect as MCPDEMO/MCPDEMO_pwd1 to localhost:1521/XEPDB1 then run:
@seeds/oracle_ddl_seed.sql

### SQL Server
Create DB InventoryDB (if missing), then run:
USE InventoryDB;
:r seeds/sqlserver_ddl_seed.sql

## Run APIs
### Permits
cd dotnet/PermitsApi
dotnet run --urls http://localhost:5000

### EHS
cd dotnet/EhsApi
dotnet run --urls http://localhost:5001

## Smoke tests
curl http://localhost:5000/health
curl -s -X POST http://localhost:5000/create_permit -H "Content-Type: application/json" -d '{"type":"Hot Work","work_order_id":"1001","location":"REFINERY-1","date":"2025-08-18","hazards":["sparks"],"approvals":["safety_officer"]}'
curl http://localhost:5001/health
curl -s -X POST http://localhost:5001/check_employee_safety -H "Content-Type: application/json" -d '{"employee_ids":["E101","E103"],"permit_type":"Hot Work"}'

## Wire to MCP servers
- WorkOrders MCP: ORACLE_USER=MCPDEMO / ORACLE_PASSWORD=MCPDEMO_pwd1 / ORACLE_DSN=localhost:1521/XEPDB1
- Inventory MCP: MSSQL_CONN_STR=Server=localhost,1433;Database=InventoryDB;User Id=sa;Password=Strong!Passw0rd;Encrypt=false;
- Permits MCP: PERMITS_API_BASE=http://localhost:5000
- EHS MCP: EHS_API_BASE=http://localhost:5001
- HR MCP: HR_FILE_PATH → your roster CSV/XLSX
