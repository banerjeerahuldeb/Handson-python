import streamlit as st
st.title('MedQuote AI – CPQ Prototype (Dummy)')
st.write('This is a placeholder. Full app code omitted for brevity.')
