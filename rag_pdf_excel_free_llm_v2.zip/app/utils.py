import re, os, pathlib
from typing import List, Dict, Any
import pandas as pd
import duckdb

TABLE_NAME_SAFE = re.compile(r"[^0-9a-zA-Z_]+")

def sanitize_table_name(name: str) -> str:
    return TABLE_NAME_SAFE.sub("_", name)

def excel_to_duckdb(con: duckdb.DuckDBPyConnection, excel_paths: List[str]) -> Dict[str, str]:
    mapping = {}
    for xp in excel_paths:
        try:
            xls = pd.ExcelFile(xp, engine='openpyxl')
            stem = pathlib.Path(xp).stem
            for sheet in xls.sheet_names:
                df = xls.parse(sheet)
                tname = sanitize_table_name(f"{stem}__{sheet}")
                con.register(tname, df)  # temp view
                con.execute(f"CREATE OR REPLACE TABLE {tname} AS SELECT * FROM {tname}")
                mapping[tname] = f"{os.path.basename(xp)} :: {sheet}"
        except Exception as e:
            print(f"Failed to load Excel {xp}: {e}")
    return mapping

def excel_to_text(excel_path: str, max_rows: int = 2000) -> str:
    out_lines = []
    try:
        xls = pd.ExcelFile(excel_path, engine='openpyxl')
        for sheet in xls.sheet_names:
            df = xls.parse(sheet).head(max_rows)
            out_lines.append(f"### File: {os.path.basename(excel_path)} | Sheet: {sheet}")
            out_lines.append("Columns: " + ", ".join(map(str, df.columns)))
            out_lines.append(df.to_csv(index=False))
    except Exception as e:
        out_lines.append(f"[Excel parse error: {e}]")
    return "\n".join(out_lines)