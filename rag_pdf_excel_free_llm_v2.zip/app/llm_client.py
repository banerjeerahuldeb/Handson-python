import os, requests
from typing import List, Dict, Any, Optional
from openai import OpenAI

def ollama_chat(messages, model: str = "llama3.1:8b", temperature: float = 0.2):
    url = "http://localhost:11434/api/chat"
    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {"temperature": temperature}
    }
    r = requests.post(url, json=payload, timeout=120)
    r.raise_for_status()
    return r.json().get("message",{}).get("content","")

def openai_chat(messages, model: str = "gpt-4o-mini", temperature: float = 0.2):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY not set.")
    client = OpenAI(api_key=api_key)
    resp = client.chat.completions.create(model=model, messages=messages, temperature=temperature)
    return resp.choices[0].message.content

def azure_openai_chat(messages, deployment: Optional[str] = None, temperature: float = 0.2):
    api_key = os.getenv("AZURE_OPENAI_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = deployment or os.getenv("AZURE_OPENAI_DEPLOYMENT")
    if not (api_key and endpoint and deployment):
        raise RuntimeError("Azure OpenAI env vars missing (AZURE_OPENAI_KEY, AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_DEPLOYMENT).")
    # Use OpenAI client with azure settings via base_url
    client = OpenAI(api_key=api_key, base_url=f"{endpoint}/openai/deployments/{deployment}")
    resp = client.chat.completions.create(model=deployment, messages=messages, temperature=temperature)
    return resp.choices[0].message.content