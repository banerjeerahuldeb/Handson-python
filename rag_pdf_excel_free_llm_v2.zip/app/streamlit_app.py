import os, io, pathlib, shutil, traceback
import streamlit as st
from typing import List, Dict, Any
from pypdf import PdfReader
from app.utils import excel_to_duckdb, excel_to_text
from app.ocr import ocr_pdf
from app.retriever import build_dense_index, hybrid_search
from app.llm_client import ollama_chat, openai_chat, azure_openai_chat
import duckdb

INDEX_DIR = "indexes"
UPLOAD_DIR = "uploads"

st.set_page_config(page_title="PDF + Excel Q&A (Online/Local LLM)", layout="wide")

st.sidebar.title("📁 Upload & Index")
uploaded_files = st.sidebar.file_uploader(
    "Upload PDFs and/or Excel files (.pdf, .xlsx, .xls)",
    type=["pdf","xlsx","xls"],
    accept_multiple_files=True
)

use_ocr = st.sidebar.checkbox("Use OCR for scanned PDFs (slower)", value=False)

if st.sidebar.button("Clear uploads"):
    shutil.rmtree(UPLOAD_DIR, ignore_errors=True)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    st.sidebar.success("Uploads cleared.")

if st.sidebar.button("(Re)build Index"):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.makedirs(INDEX_DIR, exist_ok=True)
    # Save uploads
    saved_paths = []
    if uploaded_files:
        for uf in uploaded_files:
            out_path = os.path.join(UPLOAD_DIR, uf.name)
            with open(out_path, "wb") as f:
                f.write(uf.read())
            saved_paths.append(out_path)
    else:
        saved_paths = [os.path.join(UPLOAD_DIR, p) for p in os.listdir(UPLOAD_DIR)]

    chunks, sources = [], []

    for path in saved_paths:
        p = pathlib.Path(path)
        try:
            if p.suffix.lower() == ".pdf":
                reader = PdfReader(path)
                full_text = []
                for page in reader.pages:
                    txt = page.extract_text() or ""
                    full_text.append(txt)
                text = "\n".join(full_text)
                if use_ocr and (not text.strip()):
                    text = ocr_pdf(path)
                # chunking
                words = text.split()
                size, overlap = 180, 30
                i=0
                while i < len(words):
                    ck = " ".join(words[i:i+size])
                    if ck.strip():
                        chunks.append(ck); sources.append(f"{p.name} (PDF)")
                    i += size - overlap
            elif p.suffix.lower() in (".xlsx",".xls"):
                text = excel_to_text(path)
                # chunk
                words = text.split()
                size, overlap = 220, 40
                i=0
                while i < len(words):
                    ck = " ".join(words[i:i+size])
                    if ck.strip():
                        chunks.append(ck); sources.append(f"{p.name} (Excel)")
                    i += size - overlap
        except Exception as e:
            st.sidebar.error(f"Failed to parse {p.name}: {e}")

    if not chunks:
        st.sidebar.warning("No content to index. Upload files first.")
    else:
        index, _ = build_dense_index(chunks)
        # persist
        import faiss, pickle
        faiss.write_index(index, os.path.join(INDEX_DIR, 'index.faiss'))
        with open(os.path.join(INDEX_DIR,'meta.pkl'),'wb') as f:
            pickle.dump({"chunks":chunks, "sources":sources}, f)
        st.sidebar.success(f"Indexed {len(chunks)} chunks from {len(saved_paths)} files.")

st.title("🔎 Ask Questions about your PDFs & Excels (Local or Online LLM)")

provider = st.selectbox("LLM Provider", ["Ollama (local)", "OpenAI (online)", "Azure OpenAI (online)"])
modelname = st.text_input("Model / Deployment", value="llama3.1:8b" if provider=="Ollama (local)" else ("gpt-4o-mini" if provider=="OpenAI (online)" else os.getenv("AZURE_OPENAI_DEPLOYMENT","your-deployment-name")))
mode = st.radio("Answering mode", ["Hybrid (RAG + LLM)", "Excel SQL"], horizontal=True)

query = st.text_input("Your question", placeholder="e.g., What's the total savings by team in the Excel?")

def call_llm(messages):
    if provider == "Ollama (local)":
        return ollama_chat(messages, model=modelname)
    elif provider == "OpenAI (online)":
        return openai_chat(messages, model=modelname)
    else:
        return azure_openai_chat(messages, deployment=modelname)

if st.button("Ask"):
    if not query.strip():
        st.warning("Type a question first.")
    else:
        try:
            if mode == "Hybrid (RAG + LLM)":
                # load index
                import faiss, pickle
                idx_path = os.path.join(INDEX_DIR,'index.faiss')
                meta_path = os.path.join(INDEX_DIR,'meta.pkl')
                if not (os.path.exists(idx_path) and os.path.exists(meta_path)):
                    st.error("Index not found. Upload files and click (Re)build Index first.")
                else:
                    index = faiss.read_index(idx_path)
                    with open(meta_path,'rb') as f:
                        meta = pickle.load(f)
                    reranked = hybrid_search(index, meta["chunks"], query, top_k=8)
                    hits = []
                    for i,score in reranked:
                        hits.append({
                            "score": float(score),
                            "text": meta["chunks"][i],
                            "source": meta["sources"][i]
                        })
                    context = "\n\n".join([f"[Source: {h['source']}]\n{h['text']}" for h in hits])
                    sys_prompt = (
                        "You are a precise assistant. Use only the provided context to answer. "
                        "If not enough, say you cannot find it. Cite sources by filename in [brackets]."
                    )
                    user_prompt = f"Question: {query}\n\nContext:\n{context}\n\nAnswer succinctly with citations."
                    answer = call_llm([
                        {"role":"system","content":sys_prompt},
                        {"role":"user","content":user_prompt}
                    ])
                    st.subheader("Answer")
                    st.write(answer)
                    with st.expander("Top context passages"):
                        for h in hits:
                            st.markdown(f"- **{h['source']}** (rerank={h['score']:.3f})\n\n{h['text'][:700]}...")

            else:  # Excel SQL
                excel_paths = [os.path.join(UPLOAD_DIR, p) for p in os.listdir(UPLOAD_DIR)
                               if pathlib.Path(p).suffix.lower() in (".xlsx",".xls")]
                if not excel_paths:
                    st.error("No Excel files uploaded. Upload .xlsx/.xls and try again.")
                else:
                    con = duckdb.connect(database=':memory:')
                    from app.utils import excel_to_duckdb
                    table_map = excel_to_duckdb(con, excel_paths)
                    schema_describe = []
                    for t, origin in table_map.items():
                        df = con.sql(f"SELECT * FROM {t} LIMIT 5").df()
                        schema_describe.append(f"Table {t} (from {origin}) Columns: {', '.join(map(str, df.columns))}")
                    prompt = f"""
Return ONLY a valid DuckDB SQL that answers the question. No backticks, no commentary.
Available tables and sample schemas:
{chr(10).join(schema_describe)}

Question: {query}
SQL:
"""
                    sql = call_llm([
                        {"role":"system","content":"You output only SQL, nothing else."},
                        {"role":"user","content": prompt}
                    ]).strip()
                    if sql.lower().startswith("sql"):
                        sql = sql.split("\n",1)[1] if "\n" in sql else ""
                    st.code(sql, language="sql")
                    try:
                        df = con.sql(sql).df()
                        st.dataframe(df)
                        preview = df.head(10).to_markdown(index=False)
                        summary = call_llm([
                            {"role":"system","content":"Explain the SQL result briefly for a business user."},
                            {"role":"user","content": f"SQL was:\n{sql}\n\nHere is a small sample of the result (markdown table):\n{preview}"}
                        ])
                        st.subheader("Summary")
                        st.write(summary)
                    except Exception as e:
                        st.error(f"SQL execution failed: {e}")
        except Exception as e:
            st.error("Something went wrong. See details in the console.")
            st.exception(e)

st.sidebar.markdown("---")
if st.sidebar.button("Clear indexes"):
    shutil.rmtree(INDEX_DIR, ignore_errors=True)
    os.makedirs(INDEX_DIR, exist_ok=True)
    st.sidebar.success("Indexes cleared.")

st.caption("Local or Online: BM25 + Dense + Cross-encoder rerank. OCR optional. DuckDB for Excel SQL.")