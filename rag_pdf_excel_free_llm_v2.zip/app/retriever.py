from typing import List, Dict, Any, Tuple
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer, CrossEncoder
from rank_bm25 import BM25Okapi

_EMB_MODEL = None
_RERANKER = None

def _emb():
    global _EMB_MODEL
    if _EMB_MODEL is None:
        _EMB_MODEL = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
    return _EMB_MODEL

def _cross():
    global _RERANKER
    if _RERANKER is None:
        _RERANKER = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')
    return _RERANKER

def build_dense_index(chunks: List[str]):
    embs = _emb().encode(chunks, normalize_embeddings=True, show_progress_bar=True)
    index = faiss.IndexFlatIP(embs.shape[1])
    index.add(embs.astype('float32'))
    return index, embs

def dense_search(index, chunks, query: str, k: int = 30) -> List[Tuple[int, float]]:
    q = _emb().encode([query], normalize_embeddings=True).astype('float32')
    D, I = index.search(q, k)
    return list(zip(I[0].tolist(), D[0].tolist()))

def bm25_search(chunks: List[str], query: str, k: int = 30) -> List[Tuple[int, float]]:
    tokenized_corpus = [c.split() for c in chunks]
    bm25 = BM25Okapi(tokenized_corpus)
    scores = bm25.get_scores(query.split())
    order = np.argsort(scores)[::-1][:k]
    return [(int(i), float(scores[int(i)])) for i in order]

def hybrid_search(index, chunks: List[str], query: str, k_dense: int = 30, k_bm25: int = 30, top_k: int = 10):
    dense = dense_search(index, chunks, query, k_dense)
    bm25 = bm25_search(chunks, query, k_bm25)
    # merge by index with max score normalize
    scores = {}
    for i, s in dense:
        scores[i] = max(scores.get(i, 0.0), s)
    for i, s in bm25:
        scores[i] = max(scores.get(i, 0.0), s/100.0)  # normalize BM25
    # take top N for rerank
    cand = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:max(top_k*4, 20)]
    pairs = [ (query, chunks[i]) for i,_ in cand ]
    rerank_scores = _cross().predict(pairs)
    reranked = sorted(zip([i for i,_ in cand], rerank_scores), key=lambda x: x[1], reverse=True)[:top_k]
    return reranked