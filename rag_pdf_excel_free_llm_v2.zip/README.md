# RAG Q&A over PDFs and Excel — with Online LLM Option

This upgraded app improves answer quality by adding **online LLM support** and **stronger retrieval**:
- **Providers**: Local **Ollama**, **OpenAI**, **Azure OpenAI** (choose in UI).
- **Hybrid retrieval**: **BM25 + dense vectors (FAISS)**, then **cross-encoder rerank** for higher answer precision.
- **OCR option** for scanned PDFs (Tesseract).

## Quick Start

1) Python 3.10+, then:
```bash
pip install -r requirements.txt
```
2) (Optional) **OCR**: install Tesseract on your OS (Ubuntu: `sudo apt-get install tesseract-ocr`; macOS: `brew install tesseract`; Windows: install from tesseract.github.io and ensure it's in PATH).
3) If you want **local only**, install Ollama and pull a model:
```bash
ollama pull llama3.1:8b
```
4) If you want **online LLMs**:
   - **OpenAI**: set `OPENAI_API_KEY`
   - **Azure OpenAI**: set `AZURE_OPENAI_KEY`, `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_DEPLOYMENT`

5) Run:
```bash
streamlit run app/streamlit_app.py
```

## Why this is better
- **BM25 + dense** gets both lexical and semantic matches.
- **Cross-encoder reranker** (`cross-encoder/ms-marco-MiniLM-L-6-v2`) boosts the best passages to the top.
- **OCR** extracts text from image-only PDFs.

## Notes
- Excel sheets are loaded to **DuckDB** and can be queried via **LLM-generated SQL**.
- If the SQL fails, it falls back to RAG.
- Your data never leaves your machine unless you choose an online LLM provider.